package retailStore;

class Member extends Customer {
	private String email;
	private String password;

	public Member(String firstName, String lastName, String address, String email, String password) {
		super(firstName, lastName, address);
		this.email = email;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
}
