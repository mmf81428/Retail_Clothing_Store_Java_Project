package retailStore;

import java.util.ArrayList;
import java.util.Scanner;
import retailStore.Cart;

public class MenuPage {
	
	public static void printMenu() {
		System.out.println("\nMenu:");
        System.out.println("1. View Clothing");
        System.out.println("2. View Cart");
        System.out.println("3. Exit");
        System.out.print("Select an option: ");
	}
	
	public static void executeMenu(Cart cart, ArrayList<Shirt> shirts, ArrayList<Member> members) {
        Scanner scanner = new Scanner(System.in);
        
        int option = -1;
        boolean running = true;
        while (option != 3 && running == true) {
            
        	System.out.println("\nMenu:");
            System.out.println("1. View Clothing");
            System.out.println("2. View Cart");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");            
            
            option = scanner.nextInt();
            
            if (option == 1) {
            	optionOne(running, scanner, shirts, members, cart);
            } else if (option == 2) {
                cart.displayCart();
            } else if (option ==3) {
            	break;
            } else if (option != 3) {
                System.out.println("Invalid option. Please choose again.");
            }
            menuAndCheckout(scanner, shirts, members, running, cart);
            running = false;
        }
	}
	
	private static void optionOne(boolean running, Scanner scanner, ArrayList<Shirt> shirts, ArrayList<Member> members, Cart cart) {
    	while (running) {
        	
        	System.out.println("\nAvailable Clothing: shirts\nSelect clothing type: ");
        	scanner.nextLine();
        	String clothingType = scanner.nextLine();
        	
        	System.out.println("\nAvailable colors: red, blue, black\nSelect color: ");
        	String clothingColor = scanner.nextLine();
        	
        	System.out.println("\nAvailable sizes: small, medium, large \nSelect size: ");
        	String clothingSize = scanner.nextLine();
        	
        	System.out.println("\nSelect max price: ");
        	Double maxPrice = scanner.nextDouble();
        	
        	
        	if (clothingType.equalsIgnoreCase("shirts")) {
        		
        		boolean found = false;
        		
        		for (int i = 0; i < shirts.size(); i++) {
        			if (shirts.get(i).getColor().equalsIgnoreCase(clothingColor) &&
        					shirts.get(i).getSize().equalsIgnoreCase(clothingSize) &&
        					shirts.get(i).getPrice() <= maxPrice) {
        				System.out.println("\nShirt " + (i + 1) + ":");
        				System.out.println(shirts.get(i).toString());
            			
            			found = true;
            			
        			} 
        		}
        		
        		
        		if (found == false) {
        			System.out.println("Sorry. Could not find a match");
        		}
        		
        		System.out.println("\nWould you like to add an item to the cart?");
        		scanner.nextLine();
        		String input = scanner.nextLine();
        		            		
        		if (input.equalsIgnoreCase("yes")) {
        			System.out.println("\nSelect item number: ");
        			int itemNum = scanner.nextInt();
        			
        			itemNum = itemNum - 1;
        			
        			cart.addItem(shirts.get(itemNum));
        			shirts.remove(0);
        			
        			System.out.println("\nItem added to cart.\n");
        			running = false;
        			
        		} else if (input.equalsIgnoreCase("no")) {
        			System.out.println("\nSelect an option: ");
        			System.out.println("\t1. Go back to menu");
        			System.out.println("\t2. Exit");
        			int input2 = scanner.nextInt();
        			
        			if (input2 == 1) {
        				executeMenu(cart, shirts, members);
        			} else if (input2 == 2) {
        				System.exit(0);
        			} else {
        				System.out.println("Sorry. You did not enter a correct value.");
        			}
        		}
        	} // while running
    	}
    	
    }
	
	private static void menuAndCheckout(Scanner scanner, ArrayList<Shirt> shirts, ArrayList<Member> members, Boolean running, Cart cart) {
    	System.out.println("Would you like to return to the menu?");
		scanner.nextLine();
		String userInput = scanner.nextLine();
		
		if (userInput.equalsIgnoreCase("yes")) {
			// back to menu
			running = true;
			executeMenu(cart, shirts, members);/////////////////////////////////////////////////////////////////////////////////////
			
		} else if (userInput.equalsIgnoreCase("no")) {
			System.out.println("\nWould you like to proceed to checkout?");
			userInput = scanner.nextLine();
			if (userInput.equalsIgnoreCase("yes")) {
				//proceed to checkout
				System.out.println("\nCheckout: ");
				running = false;
				
				// Prompt for account selection (member or guest)
		        System.out.println("Do you want to checkout as a member or guest?");
		        System.out.println("1. Member");
		        System.out.println("2. Guest");
		        String checkoutOption = scanner.nextLine();
				
		        if (checkoutOption.equals("1")) {
		            // Simulate member login 
		            System.out.println("\nPlease enter your email and password to login...");
		            System.out.print("Email: ");
		            String email = scanner.nextLine();
		            
		            System.out.print("Password: ");
		            String password = scanner.nextLine();
		            
		            Member foundMember = new Member(null, null, null, null, null);
		            
		            for (int i = 0; i < members.size(); i++) {
		            	if (members.get(i).getEmail().equals(email) && members.get(i).getPassword().equals(password)) {
		            		foundMember = members.get(i);
		            	}
		            }
		            
		            System.out.println("\nWelcome back, " + foundMember.getFullName());

		            // Display cart contents and confirm order
		            confirmOrder(cart, foundMember, scanner, running);

		        } else if (checkoutOption.equals("2")) {
		              // Guest checkout, collect information
		              System.out.println("\nEnter your first name:");
		              String firstName = scanner.nextLine();
		              System.out.println("\nEnter your last name:");
		              String lastName = scanner.nextLine();
		              System.out.println("\nEnter your address:");
		              String address = scanner.nextLine();
		              System.out.println("\nEnter your credit card number:");
		              String creditCardNumber = scanner.nextLine();

		              Guest guest = new Guest(firstName, lastName, address, creditCardNumber);

		              // Display cart contents and confirm order
		              confirmOrder(cart, guest, scanner, running);

		         } else {
		                System.out.println("Invalid option. Please choose 1 or 2.");
		         }
			} else if (userInput.equalsIgnoreCase("no")){
				// exit or return to menu
				System.out.println("\nRedirecting to menu...");
				executeMenu(cart, shirts, members);
				running = true;
			}
			
		}
		
	}

	private static void confirmOrder(Cart cart, Customer customer, Scanner scanner, Boolean running) {
        System.out.println("\nYour order details:");
        cart.displayCart();

        System.out.println("Are you sure you want to purchase these items?:");
        String confirmation = scanner.nextLine();
        if (confirmation.toLowerCase().equals("yes")) {
          System.out.println("\nOrder confirmed! Thank you for your purchase, " + customer.getFullName());
          running = false;
        } else {
          System.out.println("\nOrder canceled.");
        }
    }

}
