package retailStore;
import java.util.ArrayList;

class Cart {
    private ArrayList<Clothing> items;
    
    public Cart() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(Clothing item) {
        items.add(item);
    }
    
    public void removeItem(Clothing item) {
        items.remove(item);
    }
    
    public void displayCart() {
        System.out.println("\nItems in Cart:");
        
        for (Clothing item : items) {
            System.out.println(item);
        }
        
        System.out.println("");
    }
}
