package retailStore;

class Guest extends Customer {
	private String creditCardNumber;

	public Guest(String firstName, String lastName, String address, String creditCardNumber) {
		super(firstName, lastName, address);
	    this.creditCardNumber = creditCardNumber;
	}
	
	public String getCreditCardNumber() {
		return creditCardNumber;
	}
	
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}