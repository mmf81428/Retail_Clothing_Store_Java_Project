package retailStore;

class Clothing {
    private String color;
    private String size;
    private double price;
    private String type;
    
    public Clothing(String type, String color, String size, double price) {
    	this.type = type;
        this.color = color;
        this.size = size;
        this.price = price;
    }
    
    public String getType() {
    	return type;
    }
    
    public void setType(String type) {
    	this.type = type;
    }
    
    public String getColor() {
    	return color;
    }
    
    public void setColor(String color) {
    	this.color = color;
    }
    
    public String getSize() {
    	return size;
    }
    
    public void setSize(String size) {
    	this.size = size;
    }
    
    public double getPrice() {
    	return price;
    }
    
    public void setPrice(int price) {
    	this.price = price;
    }
    
    @Override
    public String toString() {
        return "Type: " + type + "\nColor: " + color + "\nSize: " + size + "\nPrice: $" + price;
    }
    
}