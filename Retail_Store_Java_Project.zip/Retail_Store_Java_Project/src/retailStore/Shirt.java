package retailStore;

class Shirt extends Clothing {
    
	public Shirt(String type, String color, String size, double price) {
        super(type, color, size, price);
    }
}